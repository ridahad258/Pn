/*
 * FleetControl Pro - synchronization safety patch
 *
 * The application used to refresh lastModified every time it loaded state
 * from localStorage. During Firebase authentication this made untouched local
 * data look newer than the cloud copy, so the old local copy could overwrite
 * the newest cloud backup. Keep the real timestamp when the data itself did
 * not change.
 */
(function installFleetStateSyncFix() {
  var stateKeys = {
    "fuel_fleet_v5_data": true,
    "fleet_control_pro_state_v1": true
  };
  var originalSetItem = Storage.prototype.setItem;

  function withoutVolatileFields(value) {
    var copy = JSON.parse(JSON.stringify(value));
    delete copy.lastModified;
    delete copy.lastBackupDate;
    return JSON.stringify(copy);
  }

  Storage.prototype.setItem = function patchedSetItem(key, value) {
    if (stateKeys[key] && typeof value === "string") {
      try {
        var previousRaw = this.getItem(key);
        var previous = previousRaw ? JSON.parse(previousRaw) : null;
        var incoming = JSON.parse(value);

        if (
          previous &&
          incoming &&
          typeof previous === "object" &&
          typeof incoming === "object" &&
          withoutVolatileFields(previous) === withoutVolatileFields(incoming)
        ) {
          if (previous.lastModified) incoming.lastModified = previous.lastModified;
          if (previous.lastBackupDate) incoming.lastBackupDate = previous.lastBackupDate;
          value = JSON.stringify(incoming);
        }
      } catch (_) {
        // Keep the application's original storage behavior for invalid data.
      }
    }

    return originalSetItem.call(this, key, value);
  };
})();